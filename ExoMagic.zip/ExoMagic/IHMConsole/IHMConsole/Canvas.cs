﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IHMConsole
{
    public class Canvas : AbstractDisplayable
    {
        protected int paddingX;
        protected int paddingY;

        private List<AbstractDisplayable> content;

        public List<AbstractDisplayable> Content
        {
            get { return content; }
            protected set { content = value; }
        }

        public Canvas(int x=0, int y=0, int width=0, int height=0) : base(x, y, width, height)
        {
            Width = (width == 0) ? MainCanvas.Instance.Width : width;
            Height = (height == 0) ? MainCanvas.Instance.Height : height;
            Content = new List<AbstractDisplayable>();
        }

        public override string Show()
        {
            foreach (AbstractDisplayable item in content)
            {
                item.Show();
            }
            return null;
        }

        public void Clear()
        {
            content.Clear();
        }

        virtual public void Add(AbstractDisplayable item)
        {
            item.X = item.X + X;
            item.Y = item.Y + Y;

            item.X = item.X + paddingX;
            item.Y = item.Y + paddingY;

            content.Add(item);
        }

        public void Remove(AbstractDisplayable item)
        {
            content.Remove(item);
        }
    }
}
