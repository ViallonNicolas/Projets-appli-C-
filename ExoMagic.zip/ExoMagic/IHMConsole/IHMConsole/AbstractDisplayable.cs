﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IHMConsole
{
    public abstract class AbstractDisplayable
    {
        public int X;
        public int Y;
        public int Width;
        public int Height;

        protected AbstractDisplayable(int x, int y, int width, int height)
        {
            X = x;
            Y = y;
            Width = width;
            Height = height;
        }

        abstract public string Show();
    }
}
