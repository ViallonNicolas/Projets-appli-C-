﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IHMConsole
{
    public class MainCanvas : Canvas
    {
        static private MainCanvas instance = null;
        static public MainCanvas Instance
        {
            get
            {
                if(instance == null)
                {
                    Instance = new MainCanvas();
                }

                return instance;
            }
            private set { instance = value; }
        }

        private MainCanvas(int width = 0, int height = 0) : base(0, 0, 1, 1)
        {
            int consoleWidth = Console.WindowWidth-1;
            int consoleHeight = Console.WindowHeight-1;

            Width = (width == 0)? consoleWidth : width;
            Height = (height == 0)? consoleHeight : height;
            paddingX = paddingY = 1;
        }

        public override string Show()
        {
            Console.Clear();
            Console.SetCursorPosition(0, 0);
            DisplayBorder();
            base.Show();
            return null;
        }

        private void DisplayBorder()
        {
            Utils.PrintAt(0, 0, "╔");
            DisplayHorizontalBar(1, 0, Width-1);
            Utils.PrintAt(Width, 0, "╗");
            DisplayVerticalBar(Width, 1, Height - 1);
            Utils.PrintAt(Width, Height, "╝");
            DisplayHorizontalBar(1, Height, Width-1);
            Utils.PrintAt(0, Height, "╚");
            DisplayVerticalBar(0, 1, Height - 1);
        }

        private void DisplayHorizontalBar(int x,int y,int max)
        {
            for (int i = x; i <= max; i++)
            {
                Utils.PrintAt(i, y, "═");
            }
        }

        private void DisplayVerticalBar(int x, int y, int max)
        {
            for (int i = y; i <= max; i++)
            {
                Utils.PrintAt(x, i, "║");
            }
        }
    }
}
