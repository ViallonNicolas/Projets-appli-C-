﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IHMConsole
{
    public abstract class AbstractModal : Canvas
    {
        public string Title;
        protected int borderMargeX = 5;
        protected int borderMargeY = 5;
        protected AbstractModal(string title, int x, int y, int width, int height) : base(x, y, width, height)
        {
            Title = title;
            if (width == 0 ) Width -= 2 * borderMargeY;
            if (height == 0) Height -= 2 * borderMargeX;

            X = (x == 0) ? (MainCanvas.Instance.Width / 2) - (Width / 2) : x;
            Y = (y == 0) ? (MainCanvas.Instance.Height / 2) - (Height / 2) : y;
        }

        protected void DisplayBorder()
        {
            Utils.PrintAt(X, Y, "#[" + Title + "]");
            for (int i = X + 3 + Title.Length; i < X + Width + 1; i++)
            {
                Utils.PrintAt(i, Y, "#");
            }
            for (int i = Y + 1; i < Y + Height; i++)
            {
                Utils.PrintAt(X, i, "|");
                for (int j = X + 1; j < X+Width; j++)
                {
                    Utils.PrintAt(j, i, " ");
                }
                Utils.PrintAt(X + Width, i, "|");
            }
            for (int i = X; i < X + Width + 1; i++)
            {
                Utils.PrintAt(i, Y + Height, "_");
            }
        }
    }
}
