﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IHMConsole
{
    public class Label : AbstractDisplayable
    {
        public string Text;

        public Label(string text,int x, int y) : base(x, y, 0, 1)
        {
            Text = text;
            Width = Text.Length;
            Height = Text.Split('\n').Length;
        }

        public override string Show()
        {
            Utils.PrintAt(X, Y, Text);
            return null;
        }
    }
}
