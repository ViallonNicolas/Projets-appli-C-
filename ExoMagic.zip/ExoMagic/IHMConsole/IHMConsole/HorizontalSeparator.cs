﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IHMConsole
{
    public class HorizontalSeparator : AbstractDisplayable
    {
        public HorizontalSeparator(int x, int y, int width=5) : base(x, y, width, 1)
        {
        }

        public override string Show()
        {
            for (int i = X; i < Width; i++)
            {
                Utils.PrintAt(i, Y, "-");
            }

            return null;
        }
    }
}
