﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IHMConsole
{
    public class InputModal : AbstractModal
    {
        public InputModal(string label,string title = "Input modal",int width = 60, int height = 4) : base(title,0, 0, width, height)
        {
            borderMargeX = 0;
            borderMargeY = 0;
            Add(new Label(label,2,2));
            Add(new InputField(3 + Content[0].Width, 2));
        }

        public override string Show()
        {
            DisplayBorder();
            Content[0].Show();
            return Content[1].Show();
        }
    }
}
