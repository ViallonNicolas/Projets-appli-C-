﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IHMConsole
{
    public class InputField : AbstractDisplayable
    {

        public InputField(int x, int y) : base(x, y, 0, 1)
        {
        }

        public override string Show()
        {
            return Utils.InputAt(X,Y);
        }
    }
}
