﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IHMConsole
{
    static class Utils
    {
        static public void PrintAt(int x, int y, string c)
        {
            Console.SetCursorPosition(x, y);
            Console.Write(c);
        }

        static public string InputAt(int x, int y)
        {
            Console.SetCursorPosition(x,y);
            return Console.ReadLine();
        }
    }
}
