﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace IHMConsole
{
    public class Modal : AbstractModal
    {
        public Modal(string title = "Fenetre", int x=0, int y=0, int width=0, int height=0) : base(title,x, y, width, height)
        {
            paddingX = paddingY = 1;
        }

        override public string Show()
        {
            DisplayBorder();
            base.Show();
            return null;
        }
    }
}
