﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp4
{
    [Serializable]
    public class carte
    {
        public string nom;
        public string desc;
        
        public carte (string nom, string desc)
        {
            this.nom = nom;
            this.desc = desc;
            
        }
       

    }
}
