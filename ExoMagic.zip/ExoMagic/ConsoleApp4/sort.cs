﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp4
{
    class sort : carte
    {
        public int cout_mana;
        public string texte_effet;
        
       
        public sort(string nom, string desc, int cout_mana, string texte_effet): base(nom, desc)
        {
            this.cout_mana = cout_mana;
            this.texte_effet = texte_effet;

        }
        public override string ToString()
        {
            return "Sort     " + nom + " \"" + desc + "\"     " + cout_mana + " mana";
        }

       
    }
}
