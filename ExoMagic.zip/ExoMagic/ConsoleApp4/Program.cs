﻿using System;
using System.Collections.Generic;
using IHMConsole;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

// constructeur de deck de 60 cartes max (4 fois max la mm carte sauf carte terrain)
// charger et sauvegarder le deck

namespace ConsoleApp4
{
    class Program
    {
        static MainCanvas MainConsole;
        static Canvas DeckCanvas;
        static Canvas CarteCanvas;
        static InputField InputMenu;
        static InputField InputCarte;
        static List<carte> Cartes;
        static List<carte> Deck;
        static int[] cptCarte = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

        static void Main(string[] args)
        {
            Cartes = new List<carte>();
            Deck = new List<carte>();
            InitDisplay();
            InitRandomCarte();
            UpdateAffichageCartes();
            string choix;
            int cptDeck = 0;

            do
            {
                MainConsole.Show();
                choix = InputMenu.Show();
                switch (choix)
                {
                    case "a":
                        cptDeck++;
                        if (cptDeck < 60)
                            AjouterCarteDeck();
                        else
                        { Console.WriteLine("Deck full : 60 cartes deja choisies"); }
                        break;
                    case "p":
                        cptDeck--;
                        SupprimerCarteDeck();
                        break;
                    case "s":
                        Save();
                        break;
                    case "c":
                        Load();
                        break;
                }
                UpdateAffichageDeck();
            } while (choix != "q");
        }

        static void InitDisplay()
        {
            MainConsole = MainCanvas.Instance;
            CarteCanvas = new Canvas(0, 0, MainConsole.Width / 2, MainConsole.Height - 8);
            MainConsole.Add(CarteCanvas);
            CarteCanvas.Add(new Label("Cartes dispos: Nom / Description / Cout en mana", 0, 0));
            CarteCanvas.Add(new HorizontalSeparator(0, 1, CarteCanvas.Width));
            DeckCanvas = new Canvas(CarteCanvas.Width, 0, MainConsole.Width, MainConsole.Height - 8);
            MainConsole.Add(DeckCanvas);
            DeckCanvas.Add(new Label("Liste des cartes choisies:", 0, 0));
            DeckCanvas.Add(new HorizontalSeparator(0, 1, DeckCanvas.Width));
            Canvas menuCanvas = new Canvas(0, DeckCanvas.Height, 0, 10);
            MainConsole.Add(menuCanvas);
            menuCanvas.Add(new HorizontalSeparator(0, 0, menuCanvas.Width));
            menuCanvas.Add(new Label("A) Ajout de carte", 0, 2));
            menuCanvas.Add(new Label("P) Suppression de carte", 0, 3));
            menuCanvas.Add(new Label("S) Sauvegarde", 0, 4));
            menuCanvas.Add(new Label("C) Chargement", 0, 5));
            menuCanvas.Add(new Label("Q) Quitter", 0, 6));
            InputMenu = new InputField(MainConsole.Width / 2, MainConsole.Height - 1);
        }
        static void AjouterCarteDeck()
        {
            Console.SetCursorPosition((MainConsole.Width / 2), MainConsole.Height - 1);
            Console.WriteLine(" ");
            Console.SetCursorPosition((MainConsole.Width / 2) - 30, MainConsole.Height - 2);
            Console.WriteLine("Ajouter une carte : taper numéro ?");
            InputCarte = new InputField(MainConsole.Width / 2, MainConsole.Height - 1);
            try
            {
                int saisie = Convert.ToInt32(InputCarte.Show());
                if (Cartes[saisie - 1].GetType() != typeof(terrain))
                {
                    cptCarte[saisie - 1]++;
                }
                if (cptCarte[saisie - 1] <= 4)
                { Deck.Add(Cartes[saisie - 1]); }
                else
                {
                    Console.WriteLine("Deja 4 cartes identiques à celle choisie, Continuer ?");
                    Console.ReadKey();
                }
            }
            catch (FormatException)
            { Console.WriteLine("Erreur de format"); }
        }
        static void SupprimerCarteDeck()
        {
            Console.SetCursorPosition((MainConsole.Width / 2), MainConsole.Height - 1);
            Console.WriteLine(" ");
            Console.SetCursorPosition((MainConsole.Width / 2) - 30, MainConsole.Height - 2);
            Console.WriteLine("Supprimer une carte : taper numéro ?");
            InputCarte = new InputField(MainConsole.Width / 2, MainConsole.Height - 1);
            try
                {
                    int saisie = Convert.ToInt32(InputCarte.Show());
                    cptCarte[saisie-1]--;
                    Deck.RemoveAt(saisie-1);
                }
             catch (Exception)
                { Console.WriteLine("Erreur non définie"); }
        }
        static void InitRandomCarte()
        {
            Random rnd = new Random();
            Cartes.Add(new creature("Pikachu  ", "monstre horrible", rnd.Next(0, 100), rnd.Next(0, 100), rnd.Next(0, 100)));
            Cartes.Add(new creature("BioHazard", "monstre horrible", rnd.Next(0, 100), rnd.Next(0, 100), rnd.Next(0, 100)));
            Cartes.Add(new sort    ("Foudre   ", "sort qui tue", rnd.Next(0, 100), "Foudroyage niv 1"));
            Cartes.Add(new terrain ("Foret    ", "plein d'arbre"));
            Cartes.Add(new creature("Zombie   ", "monstre horrible", rnd.Next(0, 100), rnd.Next(0, 100), rnd.Next(0, 100)));
            Cartes.Add(new creature("Troll    ", "monstre horrible", rnd.Next(0, 100), rnd.Next(0, 100), rnd.Next(0, 100)));
            Cartes.Add(new creature("Skelett  ", "monstre horrible", rnd.Next(0, 100), rnd.Next(0, 100), rnd.Next(0, 100)));
            Cartes.Add(new creature("Orc      ", "monstre horrible", rnd.Next(0, 100), rnd.Next(0, 100), rnd.Next(0, 100)));
            Cartes.Add(new creature("Berseker ", "monstre horrible", rnd.Next(0, 100), rnd.Next(0, 100), rnd.Next(0, 100)));
            Cartes.Add(new creature("Tyran    ", "monstre horrible", rnd.Next(0, 100), rnd.Next(0, 100), rnd.Next(0, 100)));
        }
        static void UpdateAffichageDeck()
        {
            DeckCanvas.Clear();
            DeckCanvas.Add(new Label("Liste des cartes choisies:", 0, 0));
            DeckCanvas.Add(new HorizontalSeparator(0, 1, DeckCanvas.Width));
            int y = 2;
            Label label;
            for (int j = 0; j < Deck.Count; j++)
            {
                label = new Label("Carte " + (j + 1) + " :" + Deck[j].ToString(), 0, y);
                DeckCanvas.Add(label);
                y += label.Height;
            }
        }
        static void UpdateAffichageCartes()
        {
            CarteCanvas.Clear();
            CarteCanvas.Add(new Label("Cartes:   Type   /   Nom   /   Description   / Cout mana", 0, 0));
            CarteCanvas.Add(new HorizontalSeparator(0, 1, CarteCanvas.Width));
            int y = 2;
            Label label;
            for (int i = 0; i < Cartes.Count; i++)
            {
                label = new Label("Carte " + (i + 1) + " :" + " " + Cartes[i].ToString(), 0, y);
                CarteCanvas.Add(label);
                label = new Label("|", 57, y);
                CarteCanvas.Add(label);
                y += label.Height;
            }
            for (int i = Cartes.Count; i < CarteCanvas.Height-1; i++)
            {
                label = new Label("|", 57, y);
                CarteCanvas.Add(label);
                y += label.Height;
            }
        }
        static void Save()
        {
            string fileName = new InputModal("File name:", "Save").Show();
            IFormatter formater = new BinaryFormatter();
            Stream stream = new FileStream(fileName, FileMode.OpenOrCreate, FileAccess.Write);
            formater.Serialize(stream, Deck);
            stream.Close();
        }

        static void Load()
        {
            string fileName = new InputModal("File name:", "Load").Show();
            IFormatter formater = new BinaryFormatter();
            Stream stream = new FileStream(fileName, FileMode.OpenOrCreate, FileAccess.Read);
            Deck = (List<carte>)formater.Deserialize(stream);
            stream.Close();
        }
    }
}
        