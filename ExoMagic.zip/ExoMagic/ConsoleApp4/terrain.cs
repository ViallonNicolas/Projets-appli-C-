﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp4
{
    class terrain : carte
    {
        public terrain (string nom, string desc) : base(nom, desc)
        {
        }
        public override string ToString()
        {
            return "Terrain  " + nom + " \"" + desc + "\"";
        }
    }
}
