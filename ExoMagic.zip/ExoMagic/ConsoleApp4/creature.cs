﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp4
{
    [Serializable]
    public class creature : carte
    {
        
        public int cout_mana;
        public int vie;
        public int def;
        public creature(string nom, string desc, int cout_mana, int vie, int def) : base(nom, desc)
        {
            this.cout_mana = cout_mana;
            this.vie = vie;
            this.def = def;
        }
        public override string ToString()
        {
            return "Creature " + nom + " \"" + desc + "\" " + cout_mana + " mana";
        }
    }
}
