﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class MagieAction : AbstractAction
    {
        public MagieAction()
        { }
        Random rdm = new Random();
        public override int Attack(Perso P)
        {
            TextAction(P);
            P.vie -= rdm.Next(0,10);
            return P.vie;
        }
        public override void TextAction(Perso P)
        {
            Console.WriteLine("lance une boule sur " + P.nom);
        }

    }
    
}
