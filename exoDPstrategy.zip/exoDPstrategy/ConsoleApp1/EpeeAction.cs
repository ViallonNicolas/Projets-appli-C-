﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class EpeeAction : AbstractAction
    {
        public EpeeAction()
        {

        }
        public override int Attack(Perso P)
        {
            TextAction(P);
            P.vie -= 10;
            return P.vie;
        }
        public override void TextAction(Perso P)
        {
            Console.WriteLine("Le perso " + P.nom + " se fait découper");
        }

    }
}
