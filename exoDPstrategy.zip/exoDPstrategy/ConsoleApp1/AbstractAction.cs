﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    abstract class AbstractAction
    {

    abstract public int Attack(Perso P);
    abstract public void TextAction(Perso P);
        
    }

    
}
