﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        // 2 persos s'attaque jusqua la mort de l'un des deux
        static void Main(string[] args)
        {
            
            string tmpnom;
            Console.WriteLine("rentre le nom du mage");
            tmpnom = Console.ReadLine();
            Perso Mage = new Perso(tmpnom);
            Console.WriteLine("rentre le nom de l'archer");
            tmpnom = Console.ReadLine();
            Perso Archer = new Perso(tmpnom);
            MagieAction M = new MagieAction();
            Mage.action = M;
            ArcAction A = new ArcAction();
            Archer.action = A;
            

            while (Archer.vie > 0 && Mage.vie > 0)
            {

                Mage.Attaquer(Archer);

                Console.WriteLine("Vie de" + Archer.nom + " " + Archer.vie);

                if (Archer.vie > 0)
                {
                    Archer.Attaquer(Mage);
                    Console.WriteLine("Vie de" + Mage.nom + " " + Mage.vie);
                    if (Mage.vie < 0)
                    { Console.WriteLine(Mage.nom + " est DCD."); }
                }
                else { Console.WriteLine(Archer.nom + " est décédé."); }
            }



            




        }
    }
}
