﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class Perso
    {

        public string nom;
        public int vie;
        public AbstractAction action;
        public Perso(string nom)
        {

            this.nom = nom;
            this.vie = 100;

        }

        public void Attaquer(Perso P)
        {
            Console.Write(nom + " ");
            action.Attack(P);
        }


    }
}
