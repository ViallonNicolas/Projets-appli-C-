﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class ArcAction : AbstractAction
    {
        Random rdm = new Random();
        public ArcAction()
        {

        }

        public override int Attack(Perso P)
        {
            TextAction(P);
            P.vie -= rdm.Next(20,30);
            return P.vie;
        }

        public override void TextAction(Perso P)
        {
            Console.WriteLine("tire une fleche sur " + P.nom);
        }
    }
}
