﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp3
{
    [Serializable]
    public class voiture
    {
        public string nom;
        public string marque;
        public string prix;
        public voiture ():this("toto","tata","titi")
        { }
        public voiture(string nom, string marque, string prix)
        {
            this.nom = nom;
            this.marque = marque;
            this.prix = prix;

        }

        public override string ToString()
        {
            return ("nom : " + nom + "marque :" + marque);
        }

    }
}
