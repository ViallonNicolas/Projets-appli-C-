﻿using System;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Collections.Generic;
using System.IO;
using IHMConsole;
using System.Xml;
using System.Xml.Serialization;
using System.Threading;

// enoncé: serialiser un million de fois , voiture apres voiture dans un fichier, ou serialiser un million de fois d'un coup
// en xml

namespace ConsoleApp3
{
    class Program
    {
        static MainCanvas MainConsole;
        static Canvas PersoCanvas;
        static InputField InputMenu;
        static void Main(string[] args)
        {
            List<voiture> voitures;
            voitures = new List<voiture>();
            voiture V1 = new voiture("toto", "titi", "tata");
            for (int i=0; i<1000000; i++)
            {
                voitures.Add(new voiture());
            }
            InitDisplay();
            string choix = "";
            do
            {
                MainConsole.Show();
                choix = Console.ReadLine();
                switch (choix)
                {
                    case "a":
                        voitures.Add(CreateVoiture());
                        break;
                    case "f":
                        voitures.RemoveAt(0);
                        break;
                    case "s":
                        Console.WriteLine("Sauvegarde d'un million de fois sur un fichier :");
                        XmlSerializer y = new XmlSerializer(typeof(voiture));
                        StreamWriter sy = new StreamWriter("filenew.txt");
                        for (int i = 0; i <1000000; i++)
                        { y.Serialize(sy, V1); }
                        sy.Close();
                        break;
                    case "c":
                        Console.WriteLine("Sauvegarde d'un million de voitures d'un coup");
                        XmlSerializer x = new XmlSerializer(typeof(List<voiture>));
                        StreamWriter sw = new StreamWriter("newfile.txt");
                        x.Serialize(sw, voitures);
                        sw.Close();
                        break;
                }
            } while (choix != "q");

        }

        static voiture CreateVoiture()
        {
            Console.WriteLine("saisir nom");
            string nom = Console.ReadLine();
            Console.WriteLine("saisir marque");
            string marque = Console.ReadLine();
            Console.WriteLine("saisir prix");
            string prix = Console.ReadLine();
            return new voiture(nom, marque, prix);

        }

        static void InitDisplay()
        {
            MainConsole = MainCanvas.Instance;
            PersoCanvas = new Canvas(0, 0, MainConsole.Width, MainConsole.Height - 7);
            MainConsole.Add(PersoCanvas);
            PersoCanvas.Add(new Label("Liste des personnages:", 0, 0));
            Canvas menuCanvas = new Canvas(0, PersoCanvas.Height, 0, 10);
            MainConsole.Add(menuCanvas);
            menuCanvas.Add(new HorizontalSeparator(0, 0, menuCanvas.Width));
            menuCanvas.Add(new Label("A) Ajout de voiture", 0, 1));
            menuCanvas.Add(new Label("P) Suppression de voiture", 0, 2));
            menuCanvas.Add(new Label("S) Sauvegarde 1000000 fois", 0, 3));
            menuCanvas.Add(new Label("C) Sauvegarde 1 fois", 0, 4));
            menuCanvas.Add(new Label("Q) Quitter", 0, 5));
            InputMenu = new InputField(1, MainConsole.Height - 1);

        }

    }
}
