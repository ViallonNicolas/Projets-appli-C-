﻿using System;
using System.IO;
using System.Threading;

namespace ConsoleApp1
    {
    class Program
    {
        private static Mutex mut;
        private static MyFile myfil;
        

        static void Main(string[] args)
        {
            char saisie = 'c';
            mut = new Mutex(false, "mutName");
            myfil = new MyFile("newfile.txt");
            while (saisie != ' ')
            {
                if (Console.KeyAvailable)
                { saisie = Console.ReadKey().KeyChar; }

                if (mut.WaitOne())
                {
                    Console.WriteLine("saisir");
                    myfil.WriteLineOn();
                    mut.ReleaseMutex();
                }
                else
                {
                    Console.WriteLine("dépassé");
                }
                Thread.Sleep(1);
            }






        }
    }

}
    

