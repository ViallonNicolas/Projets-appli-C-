﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace ConsoleApp1
{
    public class MyFile
    {
        private string nom;
        private string path;
        public StreamReader SR;
        public StreamWriter SW;
        public string[] tmp = null;
        

        public string Path
        {
            get { return path; }
            set { path = value; }
        }
        public MyFile(string nom)
        {
            this.nom = nom;
            path = Directory.GetCurrentDirectory();
        }
        private string GetFullPath()
        {
            return path + "\\..\\..\\..\\..\\" + nom;
        }
        public void WriteLineOn()
        {
            {
                SW = new StreamWriter(GetFullPath());
                Console.WriteLine("taper une opération");
                SW.WriteLine(Console.ReadLine());
                SW.Close();
            }
        }
        public void WriteLineMore()
        {
            SW = new StreamWriter(GetFullPath(), true);
            SW.WriteLine("and one more line");
            SW.Close();
        }
        public string LireLigne()
        {
            SR = new StreamReader(GetFullPath());
            string temp = SR.ReadLine();
            SR.Close();
            return temp;
        }
        public void LireSansEspace()
        {
            SR = new StreamReader(GetFullPath());
            string chaine;
            chaine = SR.ReadLine();
            if (chaine != null)
                tmp = chaine.Split(' ');
            else { Console.WriteLine("rien dans la chaine"); }
            SR.Close();
        }
        public void Calculer()
        {
            try {
                int x = Convert.ToInt32(tmp[0]);
                int y = Convert.ToInt32(tmp[2]);
                int result = x + y;
                Console.WriteLine(result);
            }
            catch (FormatException)
            { Console.WriteLine("Erreur de format"); }
                
        }
        public void ReadFile()
        {
            SR = new StreamReader(GetFullPath());
            while (SR.Peek() >= 0)
            {
                Console.WriteLine(SR.ReadLine());
            }
            SR.Close();
        }
    }
}
