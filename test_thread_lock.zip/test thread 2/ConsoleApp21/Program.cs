﻿using System;
using System.Threading;

namespace ConsoleApp21
{
    
    class Program
    {

        static readonly object locker = new object();
        static bool stop = false;
        static int N;
        static void Main(string[] args)
        {

            
            N = 0;
            Thread t1 = new Thread(CompteurPlus);
            t1.Start(N);
            Thread t2 = new Thread(CompteurMoins);
            t2.Start(N);
            t1.Join(10000);
            t2.Join(10000);
            stop = true;
        }

        
           
        static void CompteurPlus(object n)
        {
            
            while (!stop)
            {
                
                N++;
                
                lock(locker)
                { 
                     Console.WriteLine("valeur incrémenté 1," + N);
                     Console.WriteLine("valeur incrémenté 2," + N);
                }
                
            }
        }


        static void CompteurMoins(object n)
        {
            
            while (!stop)
            {
                N--;
                lock (locker)
                {
                    Console.WriteLine("valeur décrémenté 1," + N);
                    Console.WriteLine("valeur décrémenté 2," + N);
                }
                
            }
        }
    }
}
